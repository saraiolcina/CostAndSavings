
public class GastoException extends Exception{

	public GastoException() {
		System.out.println("No se puede hacer el retiro.");
	}

}
